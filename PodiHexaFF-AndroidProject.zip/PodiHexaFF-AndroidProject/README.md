# Podi Hexa FF — Android Studio starter project

This is a lightweight native Java Android project for a dark/red drag-headshot practice trainer. The practice slider (0–100%, default 95%) only changes training guidance. It does not automate aim, lock onto enemies, read game memory, modify Free Fire, or interfere with gameplay.

## Important limitations
- This project is source code, **not a compiled APK**.
- The master key `20101219` activates a 30-day local demo period. Local checks can be bypassed and should not be treated as secure licensing.
- Any other key currently activates demo mode as a placeholder. For real one-month subscription keys, implement server-side validation and signed expiry responses before distributing the app.
- No floating overlay permission/service is included in this starter project.

## Build a debug APK
1. Install Android Studio and a JDK 17-compatible setup.
2. Open this folder (`PodiHexaFF-AndroidProject`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK should appear at `app/build/outputs/apk/debug/app-debug.apk`.

## Build a signed release APK
1. In Android Studio choose **Build → Generate Signed Bundle / APK → APK**.
2. Create/select a keystore and choose the `release` variant.
3. Finish and locate the generated APK in `app/build/outputs/apk/release/`.

## Compatibility
Minimum Android version is Android 6.0 (API 23). The UI is built with standard Android widgets and is intended to remain lightweight on 4 GB RAM devices.
