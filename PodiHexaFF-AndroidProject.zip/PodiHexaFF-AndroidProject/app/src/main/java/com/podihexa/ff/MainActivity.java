package com.podihexa.ff;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "podi_hexa_prefs";
    private static final String MASTER_KEY = "20101219";
    private int bg = Color.rgb(10,10,10), panel = Color.rgb(25,25,25), red = Color.rgb(255,48,48), white = Color.WHITE, muted = Color.rgb(185,185,185);
    private LinearLayout root;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (System.currentTimeMillis() < prefs.getLong("expiry", 0)) showDashboard(); else showLogin();
    }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0, 6, 0, 6); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(22, 18, 22, 18); l.setBackgroundColor(bg); return l; }
    private void base(View v) { setContentView(v); }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextColor(white); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); return b; }
    private void showLogin() {
        LinearLayout l = column(); l.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("PODI HEXA FF", 29, true, red); title.setGravity(Gravity.CENTER); l.addView(title);
        TextView sub = text("DRAG HEADSHOT TRAINER", 14, true, muted); sub.setGravity(Gravity.CENTER); l.addView(sub);
        TextView label = text("Enter access key", 16, true, white); label.setPadding(0,30,0,8); l.addView(label);
        EditText key = new EditText(this); key.setSingleLine(true); key.setHint("Access key"); key.setHintTextColor(muted); key.setTextColor(white); key.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red)); l.addView(key);
        Button login = button("Unlock 1-Month Access"); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=20; l.addView(login,bp);
        l.addView(text("Practice guidance only. No auto-aim, target lock, game modification, or enemy tracking.", 12, false, muted));
        login.setOnClickListener(v -> {
            String entered = key.getText().toString().trim();
            if (entered.equals(MASTER_KEY) || entered.length() >= 8) {
                // Local demo access: the master key grants 30 days. Other keys are demo-only pending server validation.
                long expiry = System.currentTimeMillis() + 30L*24*60*60*1000;
                prefs.edit().putLong("expiry", expiry).putBoolean("demo_key", !entered.equals(MASTER_KEY)).apply();
                if (!entered.equals(MASTER_KEY)) Toast.makeText(this, "Demo access enabled locally; connect a key server for real subscription validation.", Toast.LENGTH_LONG).show();
                showDashboard();
            } else Toast.makeText(this, "Invalid key", Toast.LENGTH_SHORT).show();
        });
        base(l);
    }
    private void showDashboard() {
        ScrollView scroll = new ScrollView(this); root = column(); scroll.addView(root);
        root.addView(text("PODI HEXA FF", 28, true, red));
        root.addView(text("DRAG HEADSHOT TRAINING", 14, true, muted));
        TextView card = text("HEADSHOT PRACTICE", 18, true, white); card.setPadding(0,20,0,4); root.addView(card);
        TextView val = text("Practice recommendation: " + prefs.getInt("practice",95) + "%", 16, true, red); root.addView(val);
        SeekBar practice = new SeekBar(this); practice.setMax(100); practice.setProgress(prefs.getInt("practice",95)); practice.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); practice.setThumbTintList(android.content.res.ColorStateList.valueOf(red)); root.addView(practice);
        practice.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){ val.setText("Practice recommendation: "+p+"%"); if(u)prefs.edit().putInt("practice",p).apply(); } public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
        root.addView(text("95% is a practice recommendation only; it does not control aiming or interact with Free Fire.", 13, false, muted));
        root.addView(text("SENSITIVITY PROFILE", 18, true, white));
        addSensitivity("General", "general", 90); addSensitivity("Red Dot", "red_dot", 85); addSensitivity("2x Scope", "scope2", 80); addSensitivity("4x Scope", "scope4", 75); addSensitivity("Sniper Scope", "sniper", 45); addSensitivity("Free Look", "free_look", 70);
        root.addView(text("DRAG-DRAG PRACTICE TIPS", 18, true, white));
        root.addView(text("• Start in the training ground and practice short upward swipes.\n• Keep your thumb relaxed; use consistent swipe distance.\n• Adjust sensitivity in small steps and test each change.\n• Practice tracking stationary targets before moving targets.\n• Use only the game's normal controls; results vary by device.", 14, false, muted));
        root.addView(text("TOUCH CONTROL PREFERENCES", 18, true, white));
        addSensitivity("Touch size", "touch_size", 50); addSensitivity("Drag speed", "drag_speed", 50);
        Button reset = button("Reset Practice to 95%"); reset.setOnClickListener(v->{ practice.setProgress(95); prefs.edit().putInt("practice",95).apply(); }); root.addView(reset);
        Button logout = button("Lock App"); logout.setOnClickListener(v->{prefs.edit().putLong("expiry",0).apply();showLogin();}); root.addView(logout);
        root.addView(text("Access expiry: 30 days from local activation. This starter uses local storage; production subscription keys require secure server-side validation.", 12, false, muted));
        base(scroll);
    }
    private void addSensitivity(String label, String key, int def) {
        int current = prefs.getInt(key, def); TextView t = text(label + ": " + current, 14, true, white); root.addView(t);
        SeekBar b = new SeekBar(this); b.setMax(100); b.setProgress(current); b.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); b.setThumbTintList(android.content.res.ColorStateList.valueOf(red)); root.addView(b);
        b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){t.setText(label+": "+p);if(u)prefs.edit().putInt(key,p).apply();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
    }
}
